from flask import Flask, url_for, request

app = Flask(__name__)


@app.route("/")
def mars():
    return "Миссия Колонизация Марса"


@app.route("/load_photo", methods=["POST", "GET"])
def sample_file_upload():
    if request.method == "GET":
        return f'''<!doctype html>
                        <html lang="en">
                            <head>
                                <meta charset="utf-8">
                                <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                <link rel="stylesheet"
                                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                    crossorigin="anonymous">
                                <title>Пример загрузки файла</title>
                            </head>
                            <body>
                                <div class="container">
                                    <h1 class="text-center">Загрузка фотографии</h1>
                                    <h2 class="text-center">для участия в миссии</h2>
                                    <form method="post" enctype="multipart/form-data" class="login_form">
                                        <div class="mb-3">
                                            <label for="photo" class="form-label">Приложите фотографию</label>
                                            <input type="file" class="form-control" id="photo" name="file">
                                            <img src="{url_for('static', filename='img/loaded_photo.png')}" alt="Загруженное фото" class="img-fluid" style="max-height: 300px;">
                                        </div>
                                        <button type="submit" class="btn btn-primary">Отправить</button>
                                    </form>
                                </div>
                            </body>
                        </html>'''
    elif request.method == "POST":
        f = request.files.get("file")
        f.save("static/img/loaded_photo.png")
        return "Форма отправлена"


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
