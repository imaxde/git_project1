from flask import Flask, render_template

app = Flask(__name__)
app.config["SECRET_KEY"] = "yandexlyceum_secret_key"


@app.route("/index/<title>")
def index(title):
    return render_template("base.html", title=title)


@app.route("/list_prof/<list>")
def list_prof(list):
    list_content = ["инжинер-исследователь", "пилот", "строитель", "экзобиолог", "врач", "мнжинер по терраформированию",
                    "климатолог", "специалист по радиационной защите", "астрогеолог", "гляциолог",
                    "инжинер жизнеобеспечения", "метеоролог", "оператор марсохода", "киберинжинер", "штурман",
                    "пилот дронов"]
    return render_template("listprof.html",
                           list_variant=list,
                           list_content=list_content,
                           title="тренировка")


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
