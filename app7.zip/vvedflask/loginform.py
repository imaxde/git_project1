from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    username = StringField("ID Астронавта", validators=[DataRequired()])
    password = PasswordField("Пароль астронавта", validators=[DataRequired()])
    admin_username = StringField("ID Капитана", validators=[DataRequired()])
    admin_password = PasswordField("Пароль капитана", validators=[DataRequired()])
    submit = SubmitField("Доступ")

