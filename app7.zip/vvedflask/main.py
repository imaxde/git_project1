from flask import Flask, render_template, redirect
from loginform import LoginForm


app = Flask(__name__)
app.config["SECRET_KEY"] = "yandexlyceum_secret_key"


@app.route("/")
def index():
    return render_template("base.html", title="base")


@app.route("/login", methods=['POST', 'GET'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect("/")
    return render_template("admin_form.html", title="Аварийный доступ", form=form)


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
