from data import db_session
from data.users import User

db_session.global_init("db/blogs.db")
db_sess = db_session.create_session()
user1 = User(
    surname="Scott",
    name="Ridley",
    age=21,
    position="captain",
    speciality="research engineer",
    address="module_1",
    email="scott_chief@mars.org"
)
db_sess.add(user1)
user2 = User(
    surname="Uir",
    name="Andy",
    age=42,
    position="senior astrogeologist",
    speciality="astrogeologist",
    address="module_42",
    email="andy42@mars.org"
)
db_sess.add(user2)
user3 = User(
    surname="Watny",
    name="Mark",
    age=55,
    position="navigator",
    speciality="pilot",
    address="module_1",
    email="markwatny@mars.org"
)
user4 = User(
    surname="Kapur",
    name="Venkata",
    age=42,
    position="colonel",
    speciality="terraforming engineer",
    address="module_2",
    email="terraforming@mars.org"
)
db_sess.add(user3)
db_sess.commit()
