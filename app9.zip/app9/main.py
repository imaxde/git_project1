from flask import Flask, render_template
import json


app = Flask(__name__)
app.config["SECRET_KEY"] = "yandexlyceum_secret_key"


@app.route("/")
def index():
    return render_template("base.html", title="base")


@app.route('/member')
def news():
    with open("templates/crew.json", "rt", encoding="utf8") as f:
        crew = json.loads(f.read())
    return render_template("member.html", crew=crew)


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
